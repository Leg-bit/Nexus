package com.nexus.media.player.audio

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import com.nexus.media.data.preferences.UserPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class EqState(
    val available: Boolean = false,
    val levels: List<Int> = emptyList(),
    val minLevel: Int = 0,
    val maxLevel: Int = 0,
    val freqsHz: List<Int> = emptyList(),
    val bass: Int = 0,
    val virt: Int = 0,
    val presets: List<String> = emptyList(),
    val profiles: List<String> = emptyList()
)

/**
 * Wraps android.media.audiofx effects attached to a player's audio session.
 * Effects stay disabled while everything is flat, and a headroom factor (<= 1f) is reported
 * through [onHeadroom] so boosting bands/bass never clips (no distortion, no sudden loudness).
 */
class EqualizerManager(private val prefs: UserPreferences) {
    private var eq: Equalizer? = null
    private var bass: BassBoost? = null
    private var virt: Virtualizer? = null

    var onHeadroom: ((Float) -> Unit)? = null

    private val _state = MutableStateFlow(EqState(profiles = prefs.profiles().keys.sorted()))
    val state: StateFlow<EqState> = _state.asStateFlow()

    fun attach(session: Int) {
        detach()
        if (session <= 0) return
        try {
            eq = Equalizer(0, session)
        } catch (t: Throwable) {
            eq = null
            return
        }
        bass = runCatching { BassBoost(0, session) }.getOrNull()
        virt = runCatching { Virtualizer(0, session) }.getOrNull()
        if (prefs.eqProfile.isNotEmpty()) applyEncoded(prefs.eqProfile)
        refresh()
    }

    fun detach() {
        runCatching { eq?.release() }
        runCatching { bass?.release() }
        runCatching { virt?.release() }
        eq = null
        bass = null
        virt = null
        _state.value = _state.value.copy(available = false)
        onHeadroom?.invoke(1f)
    }

    /** Reads the real values back from the effects. */
    private fun refresh() {
        val e = eq ?: return
        val n = e.numberOfBands.toInt()
        val r = e.bandLevelRange
        _state.value = _state.value.copy(
            available = true,
            levels = (0 until n).map { e.getBandLevel(it.toShort()).toInt() },
            minLevel = r[0].toInt(),
            maxLevel = r[1].toInt(),
            freqsHz = (0 until n).map { e.getCenterFreq(it.toShort()) / 1000 },
            bass = runCatching { bass?.roundedStrength?.toInt() ?: 0 }.getOrDefault(0),
            virt = runCatching { virt?.roundedStrength?.toInt() ?: 0 }.getOrDefault(0),
            presets = (0 until e.numberOfPresets.toInt()).map { e.getPresetName(it.toShort()) }
        )
        sync()
    }

    /** Turns effects on only when needed and reports the headroom gain. */
    private fun sync() {
        val s = _state.value
        runCatching { eq?.enabled = s.levels.any { it != 0 } }
        runCatching { bass?.enabled = s.bass > 0 }
        runCatching { virt?.enabled = s.virt > 0 }
        val peak = maxOf(0, s.levels.maxOrNull() ?: 0)
        val millibels = peak + s.bass * 3 / 5
        onHeadroom?.invoke(Math.pow(10.0, -millibels / 2000.0).toFloat().coerceIn(0.1f, 1f))
    }

    private fun encode(): String {
        val s = _state.value
        return s.levels.joinToString(",") + ";" + s.bass + ";" + s.virt
    }

    private fun applyEncoded(s: String) {
        val p = s.split(";")
        if (p.size < 3) return
        val lv = p[0].split(",").mapNotNull { it.toIntOrNull() }
        eq?.let { e ->
            if (lv.size == e.numberOfBands.toInt()) {
                val lo = e.bandLevelRange[0].toInt()
                val hi = e.bandLevelRange[1].toInt()
                lv.forEachIndexed { i, l -> runCatching { e.setBandLevel(i.toShort(), l.coerceIn(lo, hi).toShort()) } }
            }
        }
        runCatching { bass?.setStrength((p[1].toIntOrNull() ?: 0).coerceIn(0, 1000).toShort()) }
        runCatching { virt?.setStrength((p[2].toIntOrNull() ?: 0).coerceIn(0, 1000).toShort()) }
    }

    private fun persist() { prefs.eqProfile = encode() }

    /** Called while a slider moves: cheap, no disk write. */
    fun setBand(i: Int, level: Int) {
        val e = eq ?: return
        val s = _state.value
        val lv = level.coerceIn(s.minLevel, s.maxLevel)
        runCatching { e.setBandLevel(i.toShort(), lv.toShort()) }
        _state.value = s.copy(levels = s.levels.toMutableList().also { if (i in it.indices) it[i] = lv })
        sync()
    }

    fun setBass(v: Int) {
        val x = v.coerceIn(0, 1000)
        runCatching { bass?.setStrength(x.toShort()) }
        _state.value = _state.value.copy(bass = x)
        sync()
    }

    fun setVirt(v: Int) {
        val x = v.coerceIn(0, 1000)
        runCatching { virt?.setStrength(x.toShort()) }
        _state.value = _state.value.copy(virt = x)
        sync()
    }

    /** Called when a slider is released: save the setting. */
    fun commit() { persist() }

    fun usePreset(i: Int) {
        runCatching { eq?.usePreset(i.toShort()) }
        refresh()
        persist()
    }

    fun reset() {
        val e = eq ?: return
        for (i in 0 until e.numberOfBands.toInt()) runCatching { e.setBandLevel(i.toShort(), 0.toShort()) }
        runCatching { bass?.setStrength(0.toShort()) }
        runCatching { virt?.setStrength(0.toShort()) }
        refresh()
        persist()
    }

    fun saveProfile(name: String) {
        prefs.saveProfile(name.replace("=", "-"), encode())
        _state.value = _state.value.copy(profiles = prefs.profiles().keys.sorted())
    }

    fun loadProfile(name: String) {
        prefs.profiles()[name]?.let { applyEncoded(it); refresh(); persist() }
    }

    fun deleteProfile(name: String) {
        prefs.deleteProfile(name)
        _state.value = _state.value.copy(profiles = prefs.profiles().keys.sorted())
    }
}
